from config import db

class Restaurant(db.Model):
    __tablename__ = 'restaurants'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    image_url = db.Column(db.String(255), nullable=True)  # Optional image URL for the restaurant
    description = db.Column(db.String(255), nullable=True)  # Optional description of the restaurant
    menu_items = db.relationship('MenuItem', backref='restaurant', lazy=True)  # Relationship to menu items

class MenuItem(db.Model):
    __tablename__ = 'menu_items'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)  # Price of the menu item
    calories = db.Column(db.Integer, nullable=False)  # Caloric content of the menu item
    image_url = db.Column(db.String(255), nullable=True)  # Optional image URL for the menu item
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurants.id'), nullable=False)  # Foreign key

