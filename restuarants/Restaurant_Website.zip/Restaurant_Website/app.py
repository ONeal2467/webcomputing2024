from config import app, db
from flask import render_template
import models
import logging

# Setup basic logging
logging.basicConfig(level=logging.INFO)

def insert_sample_data():
    if models.Restaurant.query.count() == 0:  # Only insert if no data exists
        logging.info("Inserting sample data")
        restaurants = [
            ("McDonald's", "https://source.unsplash.com/3WyvQXW9bQk/600x400", "The classic fast-food chain known for its burgers and fries.", [
                {"name": "Big Mac", "price": 3.99, "calories": 550, "image_url": "https://source.unsplash.com/u3WmDyKGsrY/600x400"},
                {"name": "McChicken", "price": 1.29, "calories": 400, "image_url": "https://source.unsplash.com/I1AgvHQOcho/600x400"}
            ]),
            ("Taco Bell", "https://source.unsplash.com/YySMqQ-vSyI/600x400", "Popular for its bold, Mexican-inspired fast-food options.", [
                {"name": "Nacho Cheese Doritos Locos Tacos", "price": 1.89, "calories": 280, "image_url": "https://source.unsplash.com/W4rxtY4XXik/600x400"},
                {"name": "Bean Burrito", "price": 1.29, "calories": 350, "image_url": "https://source.unsplash.com/8manzosDSGM/600x400"}
            ]),
            ("Arby's", "https://source.unsplash.com/S3Zc6UgQZw8/600x400", "Famous for sandwiches and an extensive menu of quick meals.", [
                {"name": "Classic Beef 'n Cheddar", "price": 3.99, "calories": 450, "image_url": "https://source.unsplash.com/bEGQz6wHmDY/600x400"},
                {"name": "Curly Fries", "price": 2.49, "calories": 330, "image_url": "https://source.unsplash.com/JC7VUHz7_r8/600x400"}
            ]),
            ("CookOut", "https://source.unsplash.com/JB06ByNIZC4/600x400", "Known for grilled burgers and milkshakes.", [
                {"name": "Big Double Burger", "price": 2.99, "calories": 500, "image_url": "https://source.unsplash.com/5tKtllqhx8Q/600x400"},
                {"name": "Milkshake", "price": 2.79, "calories": 600, "image_url": "https://source.unsplash.com/Vs-Hurgi5G0/600x400"}
            ]),
            ("Checkers", "https://source.unsplash.com/PMxT0XtQ--A/600x400", "Offers loaded burgers and famous seasoned fries.", [
                {"name": "Big Buford", "price": 3.49, "calories": 680, "image_url": "https://source.unsplash.com/d0ZxGV0Tqqk/600x400"},
                {"name": "Famous Seasoned Fries", "price": 1.99, "calories": 290, "image_url": "https://source.unsplash.com/IJkKbfZ61mA/600x400"}
            ])
        ]

        for name, image_url, description, menu_items in restaurants:
            restaurant = models.Restaurant(name=name, image_url=image_url, description=description)
            db.session.add(restaurant)
            db.session.flush()  # Assign an ID without committing the transaction
            for item in menu_items:
                menu_item = models.MenuItem(
                    name=item['name'], price=item['price'], calories=item['calories'],
                    image_url=item['image_url'], restaurant_id=restaurant.id
                )
                db.session.add(menu_item)
        db.session.commit()
        logging.info("Sample data inserted successfully.")
    else:
        logging.info("Sample data already exists in the database.")

@app.route('/')
def index():
    restaurants = models.Restaurant.query.all()
    return render_template('index.html', restaurants=restaurants)

@app.route('/menu/<int:restaurant_id>')
def menu(restaurant_id):
    restaurant = models.Restaurant.query.get_or_404(restaurant_id)
    menu_items = models.MenuItem.query.filter_by(restaurant_id=restaurant.id).all()
    return render_template('menu.html', restaurant=restaurant, menu_items=menu_items)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables
        insert_sample_data()  # Insert sample data
    app.run(debug=True)
