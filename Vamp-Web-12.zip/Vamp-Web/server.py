from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Initialize the list of classmates with some initial data
classmate_data = [
    {"name": "John Doe", "no_garlic": False, "no_shadow": True, "complexion": "Pale"},
    {"name": "Jane Smith", "no_garlic": True, "no_shadow": False, "complexion": "Olive"},
    # Add more students here if needed
]

def calculate_total_points(classmate):
    points = 0
    if classmate['no_garlic']:
        points += 3
    if classmate['no_shadow']:
        points += 4
    if classmate['complexion'] == 'Pale':
        points += 3
    return points

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/input', methods=['GET', 'POST'])
def input_form():
    if request.method == 'POST':
        # Process form data and add to classmate_data
        name = request.form.get('name')
        no_garlic = 'no_garlic' in request.form
        no_shadow = 'no_shadow' in request.form
        complexion = request.form.get('complexion')

        classmate_data.append({
            'name': name,
            'no_garlic': no_garlic,
            'no_shadow': no_shadow,
            'complexion': complexion
        })

    return render_template('input-form.html')

@app.route('/results')
def results():
    # Calculate total_points for each classmate
    for classmate in classmate_data:
        classmate['total_points'] = calculate_total_points(classmate)
        classmate['vampire_status'] = 'Vampire' if classmate['total_points'] > 6 else 'Not a Vampire'

    return render_template('results.html', classmate_data=classmate_data)

@app.route('/team')
def team():
    return render_template('team.html')

@app.route('/get_classmate_data')
def get_classmate_data():
    return jsonify(classmate_data)

if __name__ == '__main__':
    app.run(debug=True, host='localhost', port=8000)
