async function drawChart() {
    google.charts.load('current', {'packages': ['corechart']});
    google.charts.setOnLoadCallback(async () => {
        let data = new google.visualization.DataTable();
        let select = document.getElementById("vamp_select");
        let chosen_option = select.options[select.selectedIndex].text;

        let response = await fetch('/get_classmate_data');
        let classmateData = await response.json();

        let array_of_people;

        if (chosen_option === "Random Guess") {
            array_of_people = random_vamp_selector(classmateData);
        } else if (chosen_option === "Threshold Based Method") {
            array_of_people = threshold_vamp_selector(classmateData);
        } else if (chosen_option === "Decision Tree") {
            array_of_people = await desicion_tree_vamp_selector(classmateData);
        }

        classmate_data_processing(data, array_of_people[0], array_of_people[1]);

        let options = {
            'title': "How many vampires?",
            'width': 400,
            'height': 300
        };

        let chart = new google.visualization.PieChart(document.getElementById('user_info'));
        chart.draw(data, options);
    });
}

function classmate_data_processing(data, num_human, num_vampire) {
    data.addColumn('string', 'Classmate');
    data.addColumn('number', 'Vampires');
    data.addRows([
        ['Humans', num_human],
        ['Vampires', num_vampire]
    ]);
}

function random_vamp_selector(classmateData) {
    // Implement your logic here
    // Sample logic: Randomly select vampires and humans from classmateData
    let numHumans = classmateData.filter(classmate => classmate['vampire_status'] === 'Not Vampire').length;
    let numVampires = classmateData.length - numHumans;
    return [numHumans, numVampires];
}

function threshold_vamp_selector(classmateData) {
    // Implement your logic here
    // Sample logic: Count vampires and humans based on a threshold
    let numHumans = classmateData.filter(classmate => classmate['vampire_status'] === 'Not Vampire').length;
    let numVampires = classmateData.length - numHumans;
    return [numHumans, numVampires];
}

async function desicion_tree_vamp_selector(classmateData) {
    // Implement your logic here
    // Sample logic: Use a decision tree algorithm to classify vampires and humans
    let numHumans = classmateData.filter(classmate => classmate['vampire_status'] === 'Not Vampire').length;
    let numVampires = classmateData.length - numHumans;
    return [numHumans, numVampires];
}

// Call drawChart when the page loads
drawChart();
